import React from 'react'
import { View, Text } from 'react-native'

import styles from './screenheader.style'

const ScreenHeaderBtn = () => {
  return (
    <View>
      <Text>ScreenHeaderBtn</Text>
    </View>
  )
}

export default ScreenHeaderBtn